const express = require('express');
const router  = express.Router();
const db      = require('../db');

function requireLogin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Niet ingelogd' });
  next();
}

// GET /api/scores
// Geeft alle scores van de ingelogde gebruiker terug
router.get('/', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  try {
    const [rows] = await db.query(
      `SELECT game, points, wins, losses
       FROM scores
       WHERE user_id = ?
       ORDER BY game ASC`,
      [userId]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Databasefout' });
  }
});

// POST /api/score/update
// Body: { game, points, wins, losses }
// Voegt toe aan bestaande score (UPSERT)
router.post('/update', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  const { game, points = 0, wins = 0, losses = 0 } = req.body;
  if (!game) return res.status(400).json({ error: 'game is verplicht' });
  try {
    // Controleer of er al een rij bestaat voor deze user + game
    const [existing] = await db.query(
      'SELECT id FROM scores WHERE user_id = ? AND game = ?',
      [userId, game]
    );
    if (existing.length > 0) {
      await db.query(
        `UPDATE scores
         SET points = points + ?, wins = wins + ?, losses = losses + ?
         WHERE user_id = ? AND game = ?`,
        [points, wins, losses, userId, game]
      );
    } else {
      await db.query(
        `INSERT INTO scores (user_id, game, points, wins, losses)
         VALUES (?, ?, ?, ?, ?)`,
        [userId, game, points, wins, losses]
      );
    }
    res.json({ message: 'Score bijgewerkt' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Databasefout' });
  }
});

// GET /api/leaderboard?game=tictactoe&limit=20
// Geeft de top spelers terug gesorteerd op punten
router.get('/leaderboard', async (req, res) => {
  const game  = req.query.game  || null;
  const limit = Math.min(parseInt(req.query.limit) || 20, 100);
  try {
    let rows;
    if (game) {
      // Leaderboard voor één specifiek spel
      [rows] = await db.query(
        `SELECT u.username, s.game, s.points, s.wins, s.losses
         FROM scores s
         JOIN users u ON s.user_id = u.id
         WHERE s.game = ?
         ORDER BY s.points DESC, s.wins DESC
         LIMIT ?`,
        [game, limit]
      );
    } else {
      // Globaal leaderboard: sommeer alle punten per speler
      [rows] = await db.query(
        `SELECT u.username,
                SUM(s.points)  AS points,
                SUM(s.wins)    AS wins,
                SUM(s.losses)  AS losses
         FROM scores s
         JOIN users u ON s.user_id = u.id
         GROUP BY s.user_id, u.username
         ORDER BY points DESC, wins DESC
         LIMIT ?`,
        [limit]
      );
    }
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Databasefout' });
  }
});

module.exports = router;