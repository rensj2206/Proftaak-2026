const express = require('express');
const router = express.Router();
const db = require('../db');

// Middleware: moet ingelogd zijn
function requireLogin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Niet ingelogd' });
  next();
}

// GET /api/friends — haal vriendenlijst op (accepted)
router.get('/', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  try {
    const [rows] = await db.query(
      `SELECT u.id, u.username
       FROM friends f
       JOIN users u ON (
         CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END = u.id
       )
       WHERE (f.user_id = ? OR f.friend_id = ?)
         AND f.status = 'accepted'`,
      [userId, userId, userId]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Databasefout' });
  }
});

// GET /api/friends/requests — inkomende verzoeken
router.get('/requests', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  try {
    const [rows] = await db.query(
      `SELECT f.id as request_id, u.id, u.username
       FROM friends f
       JOIN users u ON f.user_id = u.id
       WHERE f.friend_id = ? AND f.status = 'pending'`,
      [userId]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Databasefout' });
  }
});

// POST /api/friends/add — stuur vriendschapsverzoek
router.post('/add', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: 'Gebruikersnaam vereist' });

  try {
    // Zoek de doelgebruiker
    const [users] = await db.query('SELECT id FROM users WHERE username = ?', [username]);
    if (users.length === 0) return res.status(404).json({ error: 'Gebruiker niet gevonden' });

    const friendId = users[0].id;
    if (friendId === userId) return res.status(400).json({ error: 'Je kunt jezelf niet toevoegen' });

    // Check of al bestaat
    const [existing] = await db.query(
      `SELECT id FROM friends
       WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)`,
      [userId, friendId, friendId, userId]
    );
    if (existing.length > 0) return res.status(400).json({ error: 'Verzoek bestaat al of al vrienden' });

    await db.query('INSERT INTO friends (user_id, friend_id, status) VALUES (?, ?, ?)',
      [userId, friendId, 'pending']);

    res.json({ message: 'Vriendschapsverzoek verzonden' });
  } catch (err) {
    res.status(500).json({ error: 'Databasefout' });
  }
});

// POST /api/friends/accept — verzoek accepteren
router.post('/accept', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  const { requestId } = req.body;
  try {
    const [result] = await db.query(
      `UPDATE friends SET status = 'accepted'
       WHERE id = ? AND friend_id = ? AND status = 'pending'`,
      [requestId, userId]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Verzoek niet gevonden' });
    res.json({ message: 'Vriendschapsverzoek geaccepteerd' });
  } catch (err) {
    res.status(500).json({ error: 'Databasefout' });
  }
});

// POST /api/friends/reject — verzoek afwijzen
router.post('/reject', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  const { requestId } = req.body;
  try {
    await db.query(
      'DELETE FROM friends WHERE id = ? AND friend_id = ? AND status = "pending"',
      [requestId, userId]
    );
    res.json({ message: 'Verzoek afgewezen' });
  } catch (err) {
    res.status(500).json({ error: 'Databasefout' });
  }
});

// DELETE /api/friends/:friendId — vriend verwijderen
router.delete('/:friendId', requireLogin, async (req, res) => {
  const userId = req.session.userId;
  const friendId = parseInt(req.params.friendId);
  try {
    await db.query(
      `DELETE FROM friends
       WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?))
         AND status = 'accepted'`,
      [userId, friendId, friendId, userId]
    );
    res.json({ message: 'Vriend verwijderd' });
  } catch (err) {
    res.status(500).json({ error: 'Databasefout' });
  }
});

module.exports = router;