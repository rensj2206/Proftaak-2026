// ── Gedeelde hulpfuncties voor alle pagina's ──

async function getUser() {
  try {
    const res = await fetch('/api/me');
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function requireLogin() {
  const user = await getUser();
  if (!user) {
    window.location.href = '/pages/index.html';
    return null;
  }
  return user;
}

async function checkAuth() {
  const user = await getUser();
  if (user) {
    window.location.href = '/pages/dashboard.html';
  }
}

async function handleLogout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/pages/index.html';
}

function showAlert(el, message, type = 'error') {
  el.textContent = message;
  el.className   = `alert alert-${type} show`;
}

function clearAlert(el) {
  el.className   = 'alert';
  el.textContent = '';
}

// ── Socket helpers ──────────────────────────────────────────────────────────
// Call this on every game/friends page right after connecting to Socket.io.
// It sets socket.userId on the server so scores can be saved correctly.
//
// Usage (at the top of any page script):
//
//   const socket = io();
//   const user = await requireLogin();
//   if (!user) return; // redirected to login
//   registerOnline(socket, user);
//
function registerOnline(socket, user) {
  // Emit immediately if already connected, or wait for connect event
  if (socket.connected) {
    socket.emit('user:online', { userId: user.id, username: user.username });
  } else {
    socket.on('connect', () => {
      socket.emit('user:online', { userId: user.id, username: user.username });
    });
  }

  // Re-register after reconnects (e.g. server restart during dev)
  socket.on('reconnect', () => {
    socket.emit('user:online', { userId: user.id, username: user.username });
  });
}