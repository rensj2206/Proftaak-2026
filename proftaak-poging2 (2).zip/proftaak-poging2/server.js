require('dotenv').config();
const express = require('express');
const session = require('express-session');
const http = require('http');
const { Server } = require('socket.io');

const authRoutes   = require('./routes/auth');
const friendRoutes = require('./routes/friends');
const scoreRoutes  = require('./routes/scores');
const db           = require('./db');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server);

app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.redirect('/pages/index.html');
});

app.use(session({
  secret:            process.env.SESSION_SECRET,
  resave:            false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 }
}));

app.use('/api',         authRoutes);
app.use('/api/friends', friendRoutes);
app.use('/api/scores',  scoreRoutes);

// ── Score helper ───────────────────────────────────────────────────────────
async function saveScore(userId, game, wins, losses, points) {
  if (!userId) return;
  try {
    const [existing] = await db.query(
      'SELECT id FROM scores WHERE user_id = ? AND game = ?',
      [userId, game]
    );
    if (existing.length > 0) {
      await db.query(
        `UPDATE scores SET points = points + ?, wins = wins + ?, losses = losses + ?
         WHERE user_id = ? AND game = ?`,
        [points, wins, losses, userId, game]
      );
    } else {
      await db.query(
        `INSERT INTO scores (user_id, game, points, wins, losses) VALUES (?, ?, ?, ?, ?)`,
        [userId, game, points, wins, losses]
      );
    }
  } catch (err) {
    console.error('Score opslaan mislukt:', err);
  }
}

// ── State ──────────────────────────────────────────────────────────────────
const onlineUsers = new Map(); // userId -> { username, socketId }
const tttRooms    = new Map(); // roomId -> room object
const c4Rooms     = new Map(); // roomId -> room object
const unoRooms    = new Map(); // roomId -> room object

// ══════════════════════════════════════════════════════════════════════════
// TTT Helper functies
// ══════════════════════════════════════════════════════════════════════════

function tttBroadcastRooms() {
  const list = Array.from(tttRooms.values())
    .filter(r => r.state !== 'done')
    .map(r => ({
      id:           r.id,
      name:         r.name,
      hostUsername: r.hostUsername,
      players:      r.players.length,
    }));
  io.emit('ttt:rooms', list);
}

function tttCheckWinner(board) {
  const lines = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6],
  ];
  for (const [a,b,c] of lines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], cells: [a,b,c] };
    }
  }
  if (board.every(Boolean)) return { winner: null, cells: null };
  return null;
}

function tttRemovePlayerFromRoom(socketId) {
  for (const [roomId, room] of tttRooms.entries()) {
    const idx = room.players.findIndex(p => p.socketId === socketId);
    if (idx === -1) continue;
    room.players.splice(idx, 1);
    if (room.players.length === 0) {
      tttRooms.delete(roomId);
    } else {
      room.state = 'waiting';
      io.to(room.players[0].socketId).emit('ttt:opponent-left');
    }
    tttBroadcastRooms();
    break;
  }
}

// ══════════════════════════════════════════════════════════════════════════
// C4 Helper functies
// ══════════════════════════════════════════════════════════════════════════

function c4BroadcastRooms() {
  const list = Array.from(c4Rooms.values())
    .filter(r => r.state !== 'done')
    .map(r => ({
      id:           r.id,
      name:         r.name,
      hostUsername: r.hostUsername,
      players:      r.players.length,
    }));
  io.emit('c4:rooms', list);
}

function c4LowestFreeRow(board, col) {
  for (let row = 5; row >= 0; row--) {
    if (board[row][col] === null) return row;
  }
  return -1;
}

function c4CheckWinner(board, lastRow, lastCol, color) {
  const directions = [[0,1],[1,0],[1,1],[1,-1]];
  for (const [dr, dc] of directions) {
    const cells = [[lastRow, lastCol]];
    for (const sign of [-1, 1]) {
      let r = lastRow + dr * sign;
      let c = lastCol + dc * sign;
      while (r >= 0 && r < 6 && c >= 0 && c < 7 && board[r][c] === color) {
        cells.push([r, c]);
        r += dr * sign;
        c += dc * sign;
      }
    }
    if (cells.length >= 4) return { winner: color, cells };
  }
  const full = board.every(row => row.every(cell => cell !== null));
  if (full) return { winner: null, cells: null };
  return null;
}

function c4RemovePlayerFromRoom(socketId) {
  for (const [roomId, room] of c4Rooms.entries()) {
    const idx = room.players.findIndex(p => p.socketId === socketId);
    if (idx === -1) continue;
    room.players.splice(idx, 1);
    if (room.players.length === 0) {
      c4Rooms.delete(roomId);
    } else {
      room.state = 'waiting';
      io.to(room.players[0].socketId).emit('c4:opponent-left');
    }
    c4BroadcastRooms();
    break;
  }
}

// ══════════════════════════════════════════════════════════════════════════
// UNO Helper functies
// ══════════════════════════════════════════════════════════════════════════

const UNO_COLORS = ['red', 'yellow', 'green', 'blue'];
const UNO_VALUES = ['0','1','2','3','4','5','6','7','8','9','skip','reverse','draw2'];

function unoBuildDeck() {
  const deck = [];
  for (const color of UNO_COLORS) {
    for (const val of UNO_VALUES) {
      deck.push({ color, value: val });
      if (val !== '0') deck.push({ color, value: val });
    }
  }
  for (let i = 0; i < 4; i++) {
    deck.push({ color: 'wild', value: 'wild' });
    deck.push({ color: 'wild', value: 'wild4' });
  }
  return deck;
}

function unoShuffle(deck) {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function unoCanPlay(card, topCard, chosenColor) {
  const activeColor = chosenColor || topCard.color;
  if (card.color === 'wild') return true;
  if (card.color === activeColor) return true;
  if (card.value === topCard.value) return true;
  return false;
}

function unoDrawCards(room, count) {
  const drawn = [];
  for (let i = 0; i < count; i++) {
    if (room.deck.length === 0) {
      const top = room.discard.splice(room.discard.length - 1, 1);
      room.deck = unoShuffle(room.discard);
      room.discard = top;
    }
    if (room.deck.length > 0) drawn.push(room.deck.pop());
  }
  return drawn;
}

function unoBroadcastRooms() {
  const list = Array.from(unoRooms.values())
    .filter(r => r.state === 'waiting')
    .map(r => ({
      id:           r.id,
      name:         r.name,
      hostUsername: r.hostUsername,
      players:      r.players.length,
      maxPlayers:   r.maxPlayers,
    }));
  io.emit('uno:rooms', list);
}

function unoNextTurn(room, skip = false) {
  const n    = room.players.length;
  const step = room.direction * (skip ? 2 : 1);
  room.currentIndex = ((room.currentIndex + step) % n + n) % n;
}

function unoRemovePlayerFromRoom(socketId) {
  for (const [roomId, room] of unoRooms.entries()) {
    const idx = room.players.findIndex(p => p.socketId === socketId);
    if (idx === -1) continue;
    const username = room.players[idx].username;
    room.players.splice(idx, 1);
    if (room.players.length === 0) {
      unoRooms.delete(roomId);
    } else {
      if (room.state === 'playing') {
        if (room.currentIndex >= room.players.length) room.currentIndex = 0;
        io.to(roomId).emit('uno:player-left', { username });
        if (room.players.length === 1) {
          room.state = 'done';
          io.to(roomId).emit('uno:game-over', { winner: room.players[0].username });
        } else {
          unoEmitState(room);
        }
      } else {
        io.to(roomId).emit('uno:player-left', { username });
      }
      room.hostUsername = room.players[0].username;
    }
    unoBroadcastRooms();
    break;
  }
}

function unoEmitState(room) {
  const topCard = room.discard[room.discard.length - 1];
  room.players.forEach(p => {
    io.to(p.socketId).emit('uno:state', {
      hand:          p.hand,
      topCard,
      chosenColor:   room.chosenColor,
      currentIndex:  room.currentIndex,
      currentUserId: room.players[room.currentIndex]?.userId,
      direction:     room.direction,
      players: room.players.map(q => ({
        userId:   q.userId,
        username: q.username,
        cards:    q.hand.length,
        saidUno:  q.saidUno,
      })),
      deckSize:    room.deck.length,
      pendingDraw: room.pendingDraw || 0,
    });
  });
}

// ══════════════════════════════════════════════════════════════════════════
// Socket.io
// ══════════════════════════════════════════════════════════════════════════
io.on('connection', (socket) => {

  // ── Aanwezigheid & chat ──────────────────────────────────────────────

  socket.on('user:online', ({ userId, username }) => {
    socket.userId   = userId;
    socket.username = username;
    onlineUsers.set(userId, { username, socketId: socket.id });
    io.emit('users:online', Array.from(onlineUsers.entries()).map(([id, data]) => ({
      userId: id, username: data.username
    })));
  });

  socket.on('chat:message', ({ message }) => {
    if (!socket.userId || !message?.trim()) return;
    io.emit('chat:message', {
      userId:    socket.userId,
      username:  socket.username,
      message:   message.trim(),
      timestamp: new Date().toISOString()
    });
  });

  socket.on('chat:private', ({ toUserId, message }) => {
    if (!socket.userId || !message?.trim()) return;
    const target  = onlineUsers.get(toUserId);
    const payload = {
      from:      { userId: socket.userId, username: socket.username },
      message:   message.trim(),
      timestamp: new Date().toISOString()
    };
    if (target) io.to(target.socketId).emit('chat:private', payload);
    socket.emit('chat:private:sent', { toUserId, ...payload });
  });

  // ── Module 4: Boter Kaas en Ei ──────────────────────────────────────

  socket.on('ttt:get-rooms', () => {
    const list = Array.from(tttRooms.values())
      .filter(r => r.state !== 'done')
      .map(r => ({
        id: r.id, name: r.name, hostUsername: r.hostUsername, players: r.players.length,
      }));
    socket.emit('ttt:rooms', list);
  });

  socket.on('ttt:create-room', ({ roomName }) => {
    if (!socket.userId) return;
    if (!roomName?.trim()) return socket.emit('ttt:error', { message: 'Ongeldige kamernaam.' });
    tttRemovePlayerFromRoom(socket.id);
    const roomId = `ttt_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    const room = {
      id: roomId, name: roomName.trim(), hostUsername: socket.username,
      players: [{ socketId: socket.id, userId: socket.userId, username: socket.username, symbol: 'X' }],
      board: Array(9).fill(null), currentTurn: 'X', rematchVotes: new Set(), state: 'waiting',
    };
    tttRooms.set(roomId, room);
    socket.join(roomId);
    socket.emit('ttt:room-created', { roomId });
    tttBroadcastRooms();
  });

  socket.on('ttt:join-room', ({ roomId }) => {
    if (!socket.userId) return;
    const room = tttRooms.get(roomId);
    if (!room)                                              return socket.emit('ttt:error', { message: 'Kamer niet gevonden.' });
    if (room.players.length >= 2)                           return socket.emit('ttt:error', { message: 'Kamer is vol.' });
    if (room.players.find(p => p.userId === socket.userId)) return socket.emit('ttt:error', { message: 'Je zit al in deze kamer.' });
    tttRemovePlayerFromRoom(socket.id);
    room.players.push({ socketId: socket.id, userId: socket.userId, username: socket.username, symbol: 'O' });
    room.state = 'playing';
    socket.join(roomId);
    io.to(roomId).emit('ttt:game-start', {
      roomId,
      players: room.players.map(p => ({ userId: p.userId, username: p.username, symbol: p.symbol })),
    });
    tttBroadcastRooms();
  });

  socket.on('ttt:move', ({ roomId, index }) => {
    const room = tttRooms.get(roomId);
    if (!room || room.state !== 'playing') return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player || player.symbol !== room.currentTurn || room.board[index] !== null) return;
    room.board[index] = player.symbol;
    io.to(roomId).emit('ttt:move', { index, symbol: player.symbol, board: room.board });
    const result = tttCheckWinner(room.board);
    if (result !== null) {
      room.state = 'done';
      io.to(roomId).emit('ttt:game-over', { winner: result.winner, winCells: result.cells, board: room.board });
      if (result.winner) {
        const winner = room.players.find(p => p.symbol === result.winner);
        const loser  = room.players.find(p => p.symbol !== result.winner);
        if (winner) saveScore(winner.userId, 'tictactoe', 1, 0, 10);
        if (loser)  saveScore(loser.userId,  'tictactoe', 0, 1, 0);
      } else {
        room.players.forEach(p => saveScore(p.userId, 'tictactoe', 0, 0, 3));
      }
      tttBroadcastRooms();
      return;
    }
    room.currentTurn = room.currentTurn === 'X' ? 'O' : 'X';
  });

  // FIX: track rematch votes by userId instead of socketId
  socket.on('ttt:rematch', ({ roomId }) => {
    const room = tttRooms.get(roomId);
    if (!room) return;
    const player = room.players.find(p => p.userId === socket.userId);
    if (!player) return;
    room.rematchVotes.add(player.userId);
    io.to(roomId).emit('ttt:rematch-vote', { votes: room.rematchVotes.size });
    if (room.rematchVotes.size >= 2) {
      room.players.forEach(p => { p.symbol = p.symbol === 'X' ? 'O' : 'X'; });
      room.board       = Array(9).fill(null);
      room.currentTurn = 'X';
      room.state       = 'playing';
      room.rematchVotes.clear();
      room.players.forEach(p => {
        io.to(p.socketId).emit('ttt:rematch-ready', { startSymbol: p.symbol });
      });
      tttBroadcastRooms();
    }
  });

  socket.on('ttt:leave-room', ({ roomId }) => {
    const room = tttRooms.get(roomId);
    if (!room) return;
    socket.leave(roomId);
    tttRemovePlayerFromRoom(socket.id);
  });

  // ── Module 5: 4 op een rij ──────────────────────────────────────────

  socket.on('c4:get-rooms', () => {
    const list = Array.from(c4Rooms.values())
      .filter(r => r.state !== 'done')
      .map(r => ({
        id: r.id, name: r.name, hostUsername: r.hostUsername, players: r.players.length,
      }));
    socket.emit('c4:rooms', list);
  });

  socket.on('c4:create-room', ({ roomName }) => {
    if (!socket.userId) return;
    if (!roomName?.trim()) return socket.emit('c4:error', { message: 'Ongeldige kamernaam.' });
    c4RemovePlayerFromRoom(socket.id);
    const roomId = `c4_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    const room = {
      id: roomId, name: roomName.trim(), hostUsername: socket.username,
      players: [{ socketId: socket.id, userId: socket.userId, username: socket.username, color: 'red' }],
      board: Array.from({ length: 6 }, () => Array(7).fill(null)),
      currentTurn: 'red', rematchVotes: new Set(), state: 'waiting',
    };
    c4Rooms.set(roomId, room);
    socket.join(roomId);
    socket.emit('c4:room-created', { roomId });
    c4BroadcastRooms();
  });

  socket.on('c4:join-room', ({ roomId }) => {
    if (!socket.userId) return;
    const room = c4Rooms.get(roomId);
    if (!room)                                              return socket.emit('c4:error', { message: 'Kamer niet gevonden.' });
    if (room.players.length >= 2)                           return socket.emit('c4:error', { message: 'Kamer is vol.' });
    if (room.players.find(p => p.userId === socket.userId)) return socket.emit('c4:error', { message: 'Je zit al in deze kamer.' });
    c4RemovePlayerFromRoom(socket.id);
    room.players.push({ socketId: socket.id, userId: socket.userId, username: socket.username, color: 'yellow' });
    room.state = 'playing';
    socket.join(roomId);
    io.to(roomId).emit('c4:game-start', {
      roomId,
      players: room.players.map(p => ({ userId: p.userId, username: p.username, color: p.color })),
    });
    c4BroadcastRooms();
  });

  socket.on('c4:move', ({ roomId, col }) => {
    const room = c4Rooms.get(roomId);
    if (!room || room.state !== 'playing') return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player || player.color !== room.currentTurn || col < 0 || col > 6) return;
    const row = c4LowestFreeRow(room.board, col);
    if (row === -1) return;
    room.board[row][col] = player.color;
    io.to(roomId).emit('c4:move', { col, row, color: player.color, board: room.board });
    const result = c4CheckWinner(room.board, row, col, player.color);
    if (result !== null) {
      room.state = 'done';
      io.to(roomId).emit('c4:game-over', { winner: result.winner, winCells: result.cells, board: room.board });
      if (result.winner) {
        const winner = room.players.find(p => p.color === result.winner);
        const loser  = room.players.find(p => p.color !== result.winner);
        if (winner) saveScore(winner.userId, 'connect4', 1, 0, 10);
        if (loser)  saveScore(loser.userId,  'connect4', 0, 1, 0);
      } else {
        room.players.forEach(p => saveScore(p.userId, 'connect4', 0, 0, 3));
      }
      c4BroadcastRooms();
      return;
    }
    room.currentTurn = room.currentTurn === 'red' ? 'yellow' : 'red';
  });

  // FIX: track rematch votes by userId instead of socketId
  socket.on('c4:rematch', ({ roomId }) => {
    const room = c4Rooms.get(roomId);
    if (!room) return;
    const player = room.players.find(p => p.userId === socket.userId);
    if (!player) return;
    room.rematchVotes.add(player.userId);
    io.to(roomId).emit('c4:rematch-vote', { votes: room.rematchVotes.size });
    if (room.rematchVotes.size >= 2) {
      room.players.forEach(p => { p.color = p.color === 'red' ? 'yellow' : 'red'; });
      room.board       = Array.from({ length: 6 }, () => Array(7).fill(null));
      room.currentTurn = 'red';
      room.state       = 'playing';
      room.rematchVotes.clear();
      room.players.forEach(p => {
        io.to(p.socketId).emit('c4:rematch-ready', { startColor: p.color });
      });
      c4BroadcastRooms();
    }
  });

  socket.on('c4:leave-room', ({ roomId }) => {
    const room = c4Rooms.get(roomId);
    if (!room) return;
    socket.leave(roomId);
    c4RemovePlayerFromRoom(socket.id);
  });

  // ── Module 6: UNO ───────────────────────────────────────────────────

  socket.on('uno:get-rooms', () => {
    const list = Array.from(unoRooms.values())
      .filter(r => r.state === 'waiting')
      .map(r => ({
        id: r.id, name: r.name, hostUsername: r.hostUsername,
        players: r.players.length, maxPlayers: r.maxPlayers,
      }));
    socket.emit('uno:rooms', list);
  });

  socket.on('uno:create-room', ({ roomName, maxPlayers }) => {
    if (!socket.userId) return;
    if (!roomName?.trim()) return socket.emit('uno:error', { message: 'Ongeldige kamernaam.' });
    const max = Math.min(Math.max(parseInt(maxPlayers) || 4, 2), 4);
    unoRemovePlayerFromRoom(socket.id);
    const roomId = `uno_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    const room = {
      id: roomId, name: roomName.trim(), hostUsername: socket.username, maxPlayers: max,
      players: [{ socketId: socket.id, userId: socket.userId, username: socket.username, hand: [], saidUno: false }],
      deck: [], discard: [], currentIndex: 0, direction: 1,
      chosenColor: null, pendingDraw: 0, pendingStackValue: null,
      rematchVotes: new Set(), state: 'waiting',
    };
    unoRooms.set(roomId, room);
    socket.join(roomId);
    socket.emit('uno:room-created', { roomId });
    unoBroadcastRooms();
  });

  socket.on('uno:join-room', ({ roomId }) => {
    if (!socket.userId) return;
    const room = unoRooms.get(roomId);
    if (!room)                                              return socket.emit('uno:error', { message: 'Kamer niet gevonden.' });
    if (room.state !== 'waiting')                           return socket.emit('uno:error', { message: 'Spel is al begonnen.' });
    if (room.players.length >= room.maxPlayers)             return socket.emit('uno:error', { message: 'Kamer is vol.' });
    if (room.players.find(p => p.userId === socket.userId)) return socket.emit('uno:error', { message: 'Je zit al in deze kamer.' });
    unoRemovePlayerFromRoom(socket.id);
    room.players.push({ socketId: socket.id, userId: socket.userId, username: socket.username, hand: [], saidUno: false });
    socket.join(roomId);
    io.to(roomId).emit('uno:player-joined', {
      username: socket.username,
      players:  room.players.map(p => ({ userId: p.userId, username: p.username })),
    });
    unoBroadcastRooms();
  });

  socket.on('uno:start-game', ({ roomId }) => {
    const room = unoRooms.get(roomId);
    if (!room) return;
    if (room.players[0].socketId !== socket.id) return socket.emit('uno:error', { message: 'Alleen de host kan starten.' });
    if (room.players.length < 2)                return socket.emit('uno:error', { message: 'Minimaal 2 spelers nodig.' });
    room.deck = unoShuffle(unoBuildDeck());
    room.players.forEach(p => { p.hand = unoDrawCards(room, 7); p.saidUno = false; });
    let startCard;
    do {
      startCard = room.deck.pop();
      if (startCard.color === 'wild') room.deck.unshift(startCard);
    } while (startCard.color === 'wild');
    room.discard            = [startCard];
    room.currentIndex       = 0;
    room.direction          = 1;
    room.chosenColor        = null;
    room.pendingDraw        = 0;
    room.pendingStackValue  = null;
    room.rematchVotes.clear();
    room.state              = 'playing';
    io.to(roomId).emit('uno:game-start', {
      players: room.players.map(p => ({ userId: p.userId, username: p.username })),
    });
    unoEmitState(room);
    unoBroadcastRooms();
  });

  socket.on('uno:play-card', ({ roomId, cardIndex, chosenColor }) => {
    const room = unoRooms.get(roomId);
    if (!room || room.state !== 'playing') return;
    const player = room.players[room.currentIndex];
    if (!player || player.socketId !== socket.id) return socket.emit('uno:error', { message: 'Niet jouw beurt.' });
    const card = player.hand[cardIndex];
    if (!card) return socket.emit('uno:error', { message: 'Ongeldige kaart.' });
    const topCard = room.discard[room.discard.length - 1];
    if (room.pendingDraw > 0) {
      const canStack = (room.pendingStackValue === 'draw2' && card.value === 'draw2') ||
                       (room.pendingStackValue === 'wild4'  && card.value === 'wild4');
      if (!canStack) return socket.emit('uno:error', { message: `Je moet ${room.pendingDraw} kaarten trekken of stapelen.` });
    } else {
      if (!unoCanPlay(card, topCard, room.chosenColor))
        return socket.emit('uno:error', { message: 'Die kaart mag je niet spelen.' });
    }
    if (card.color === 'wild' && !chosenColor)
      return socket.emit('uno:error', { message: 'Kies een kleur voor de wild kaart.' });
    player.hand.splice(cardIndex, 1);
    player.saidUno = false;
    room.discard.push(card);
    room.chosenColor = card.color === 'wild' ? chosenColor : null;
    io.to(roomId).emit('uno:card-played', {
      userId: player.userId, username: player.username, card, chosenColor: room.chosenColor,
    });
    if (player.hand.length === 0) {
      room.state = 'done';
      io.to(roomId).emit('uno:game-over', { winner: player.username });
      saveScore(player.userId, 'uno', 1, 0, 20);
      room.players.filter(p => p.userId !== player.userId)
                  .forEach(p => saveScore(p.userId, 'uno', 0, 1, 0));
      unoBroadcastRooms();
      return;
    }
    if (player.hand.length === 1 && !player.saidUno) {
      const penalty = unoDrawCards(room, 2);
      penalty.forEach(c => player.hand.push(c));
      io.to(player.socketId).emit('uno:drew-cards', { cards: penalty, reason: 'forgot-uno' });
      io.to(roomId).emit('uno:forgot-uno', { username: player.username });
    }
    if (card.value === 'reverse') {
      room.direction *= -1;
      unoNextTurn(room, room.players.length === 2);
      room.pendingDraw = 0; room.pendingStackValue = null;
    } else if (card.value === 'skip') {
      unoNextTurn(room, true);
      room.pendingDraw = 0; room.pendingStackValue = null;
    } else if (card.value === 'draw2') {
      room.pendingDraw += 2; room.pendingStackValue = 'draw2';
      unoNextTurn(room);
    } else if (card.value === 'wild4') {
      room.pendingDraw += 4; room.pendingStackValue = 'wild4';
      unoNextTurn(room);
    } else {
      room.pendingDraw = 0; room.pendingStackValue = null;
      unoNextTurn(room);
    }
    unoEmitState(room);
  });

  socket.on('uno:draw-card', ({ roomId }) => {
    const room = unoRooms.get(roomId);
    if (!room || room.state !== 'playing') return;
    const player = room.players[room.currentIndex];
    if (!player || player.socketId !== socket.id) return;
    const drawCount = room.pendingDraw > 0 ? room.pendingDraw : 1;
    const drawn = unoDrawCards(room, drawCount);
    drawn.forEach(c => player.hand.push(c));
    room.pendingDraw = 0; room.pendingStackValue = null;
    io.to(player.socketId).emit('uno:drew-cards', { cards: drawn, reason: 'draw' });
    io.to(roomId).emit('uno:player-drew', { username: player.username, count: drawn.length });
    unoNextTurn(room);
    unoEmitState(room);
  });

  socket.on('uno:say-uno', ({ roomId }) => {
    const room = unoRooms.get(roomId);
    if (!room) return;
    const player = room.players.find(p => p.socketId === socket.id);
    if (!player || player.hand.length !== 1) return;
    player.saidUno = true;
    io.to(roomId).emit('uno:uno-called', { username: player.username });
  });

  socket.on('uno:challenge-uno', ({ roomId, targetUserId }) => {
    const room = unoRooms.get(roomId);
    if (!room) return;
    const target = room.players.find(p => p.userId === targetUserId);
    if (!target || target.hand.length !== 1 || target.saidUno) return;
    const penalty = unoDrawCards(room, 2);
    penalty.forEach(c => target.hand.push(c));
    io.to(target.socketId).emit('uno:drew-cards', { cards: penalty, reason: 'challenge' });
    io.to(roomId).emit('uno:challenge-success', { challenger: socket.username, target: target.username });
    unoEmitState(room);
  });

  // FIX: UNO rematch — track votes by userId, reset full game state
  socket.on('uno:rematch', ({ roomId }) => {
    const room = unoRooms.get(roomId);
    if (!room) return;
    const player = room.players.find(p => p.userId === socket.userId);
    if (!player) return;
    room.rematchVotes.add(player.userId);
    io.to(roomId).emit('uno:rematch-vote', { votes: room.rematchVotes.size, needed: room.players.length });
    if (room.rematchVotes.size >= room.players.length) {
      room.deck = unoShuffle(unoBuildDeck());
      room.players.forEach(p => { p.hand = unoDrawCards(room, 7); p.saidUno = false; });
      let startCard;
      do {
        startCard = room.deck.pop();
        if (startCard.color === 'wild') room.deck.unshift(startCard);
      } while (startCard.color === 'wild');
      room.discard           = [startCard];
      room.currentIndex      = 0;
      room.direction         = 1;
      room.chosenColor       = null;
      room.pendingDraw       = 0;
      room.pendingStackValue = null;
      room.rematchVotes.clear();
      room.state             = 'playing';
      io.to(roomId).emit('uno:rematch-ready', {
        players: room.players.map(p => ({ userId: p.userId, username: p.username })),
      });
      unoEmitState(room);
      unoBroadcastRooms();
    }
  });

  socket.on('uno:leave-room', ({ roomId }) => {
    const room = unoRooms.get(roomId);
    if (!room) return;
    socket.leave(roomId);
    unoRemovePlayerFromRoom(socket.id);
  });

  // ── Disconnect ───────────────────────────────────────────────────────

  socket.on('disconnect', () => {
    if (socket.userId) {
      onlineUsers.delete(socket.userId);
      io.emit('users:online', Array.from(onlineUsers.entries()).map(([id, data]) => ({
        userId: id, username: data.username
      })));
    }
    tttRemovePlayerFromRoom(socket.id);
    c4RemovePlayerFromRoom(socket.id);
    unoRemovePlayerFromRoom(socket.id);
  });
});

// ── Start ──────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server draait op http://localhost:${PORT}`));